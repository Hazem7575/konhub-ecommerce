<?php

namespace Konhub\Lido\Units\Styles;

class ZindexUnit
{
    public static function rander($zindex)
    {
        return 'z-index:' . $zindex . ';';
    }
}